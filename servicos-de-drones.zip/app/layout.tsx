import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Ponto de Vista Aéreo | Filmagem e Fotografia com Drone',
  description:
    'Filmagem e fotografia aérea profissional com drone: imóveis, conteúdo para redes sociais, eventos, inspeção de telhados e vídeos para turismo e hotelaria.',
  generator: 'v0.app',
  keywords: [
    'drone',
    'filmagem aérea',
    'fotografia aérea',
    'imóveis',
    'eventos',
    'inspeção de telhados',
    'turismo',
    'hotelaria',
  ],
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0b0e14',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${spaceGrotesk.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
