// Configurações do site. Ajuste os contatos abaixo com seus dados reais.
export const site = {
  name: 'Ponto de Vista Aéreo',
  tagline: 'Filmagem e fotografia aérea com drone',
  region: 'Porto Alegre e Região',
  whatsappNumber: '5551995614476',
  instagram: 'https://instagram.com/breno.drones',
} as const

export function whatsappLink(message?: string) {
  const base = `https://wa.me/${site.whatsappNumber}`
  const text =
    message ??
    'Olá! Vim pelo site e gostaria de um orçamento para filmagem/fotografia com drone.'
  return `${base}?text=${encodeURIComponent(text)}`
}
