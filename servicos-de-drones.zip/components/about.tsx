const stats = [
  { value: 'HD / 4K', label: 'Captação em alta resolução' },
  { value: 'Rápido', label: 'Entrega ágil das imagens' },
  { value: 'Legal', label: 'Voos com segurança e responsabilidade' },
]

export function About() {
  return (
    <section id="sobre" className="mx-auto max-w-6xl px-5 py-24 md:py-32">
      <div className="grid items-center gap-12 md:grid-cols-2">
        <div className="relative overflow-hidden rounded-2xl border border-border">
          <img
            src="/images/about-drone.png"
            alt="Drone profissional em voo ao pôr do sol"
            className="aspect-[4/5] w-full object-cover"
          />
        </div>

        <div>
          <p className="text-sm font-medium uppercase tracking-widest text-primary">Sobre</p>
          <h2 className="mt-3 text-balance font-heading text-3xl font-bold tracking-tight sm:text-4xl">
            Um olhar que sai do chão
          </h2>
          <div className="mt-5 space-y-4 text-pretty leading-relaxed text-muted-foreground">
            <p>
              A <span className="text-foreground">Ponto de Vista Aéreo</span> nasceu da paixão por
              enxergar o mundo de outro ângulo. Atuando em <span className="text-foreground">Porto
              Alegre e Região</span>, com drone e olhar cinematográfico, transformo lugares, imóveis
              e momentos em imagens que chamam atenção e contam histórias.
            </p>
            <p>
              Cada voo é planejado com cuidado — enquadramento, luz e segurança — para entregar
              exatamente o que o seu projeto precisa, seja uma venda mais rápida, um vídeo que
              engaja ou um registro inesquecível.
            </p>
          </div>

          <dl className="mt-8 grid grid-cols-3 gap-4">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border border-border bg-card p-4">
                <dt className="font-heading text-lg font-semibold text-primary">{s.value}</dt>
                <dd className="mt-1 text-xs leading-relaxed text-muted-foreground">{s.label}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
