import { Building2, Clapperboard, PartyPopper, ShieldCheck, Palmtree } from 'lucide-react'

const services = [
  {
    icon: Building2,
    title: 'Fotografia e filmagem imobiliária',
    desc: 'Destaque imóveis com ângulos aéreos que mostram localização, terreno e potencial em poucos segundos.',
    image: '/images/service-real-estate.png',
    alt: 'Vista aérea de uma casa de luxo com piscina ao entardecer',
    span: 'md:col-span-2 md:row-span-2',
  },
  {
    icon: Clapperboard,
    title: 'Conteúdo para redes sociais',
    desc: 'Vídeos dinâmicos e prontos para engajar no Instagram, TikTok e YouTube.',
    image: '/images/service-social.png',
    alt: 'Drone acompanhando pessoa em trilha ao nascer do sol',
    span: '',
  },
  {
    icon: PartyPopper,
    title: 'Cobertura de eventos ao ar livre',
    desc: 'Casamentos, festivais e confraternizações registrados de uma perspectiva única.',
    image: '/images/service-events.png',
    alt: 'Vista aérea de evento ao ar livre em campo verde no fim de tarde',
    span: '',
  },
  {
    icon: ShieldCheck,
    title: 'Inspeção de telhados e fachadas',
    desc: 'Documentação visual detalhada e segura, sem andaimes nem riscos.',
    image: '/images/service-inspection.png',
    alt: 'Vista aérea aproximada de telhado durante inspeção técnica',
    span: '',
  },
  {
    icon: Palmtree,
    title: 'Vídeos para turismo e hotelaria',
    desc: 'Mostre pousadas, resorts e destinos com imagens que despertam o desejo de visitar.',
    image: '/images/service-tourism.png',
    alt: 'Vista aérea de resort tropical com piscina e mar azul-turquesa',
    span: '',
  },
]

export function Services() {
  return (
    <section id="servicos" className="mx-auto max-w-6xl px-5 py-24 md:py-32">
      <div className="max-w-2xl">
        <p className="text-sm font-medium uppercase tracking-widest text-primary">Serviços</p>
        <h2 className="mt-3 text-balance font-heading text-3xl font-bold tracking-tight sm:text-4xl">
          O que eu capturo do alto
        </h2>
        <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
          Cada projeto é planejado para o objetivo do cliente — do imóvel à venda ao
          vídeo que emociona. Escolha o que combina com a sua necessidade.
        </p>
      </div>

      <div className="mt-12 grid auto-rows-[220px] grid-cols-1 gap-4 md:grid-cols-3">
        {services.map((s) => {
          const Icon = s.icon
          return (
            <article
              key={s.title}
              className={`group relative overflow-hidden rounded-2xl border border-border ${s.span}`}
            >
              <img
                src={s.image || '/placeholder.svg'}
                alt={s.alt}
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              <div className="relative flex h-full flex-col justify-end p-6">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary backdrop-blur-sm">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="mt-4 font-heading text-lg font-semibold leading-snug">{s.title}</h3>
                <p className="mt-1.5 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {s.desc}
                </p>
              </div>
            </article>
          )
        })}
      </div>
    </section>
  )
}
