const shots = [
  { src: '/images/aerea-poa-gasometro.jpg', alt: 'Usina do Gasômetro à beira do Guaíba em Porto Alegre, vista aérea', location: 'Porto Alegre — Usina do Gasômetro', tall: false },
  { src: '/images/aerea-molhes-farol.jpg', alt: 'Molhes com farol e pescadores em Torres, vista aérea', location: 'Torres — Molhes', tall: true },
  { src: '/images/aerea-orla-amanhecer.jpg', alt: 'Orla com o sol refletindo no mar ao amanhecer, vista aérea', location: 'Litoral — Amanhecer na orla', tall: false },
  { src: '/images/aerea-santuario-por-do-sol.jpg', alt: 'Santuário no morro ao pôr do sol com a cidade ao fundo, vista aérea', location: 'Grande POA — Santuário ao pôr do sol', tall: false },
  { src: '/images/aerea-poa-pontal-guaiba.jpg', alt: 'Torre de vidro do Pontal à beira do Guaíba em Porto Alegre, vista aérea', location: 'Porto Alegre — Pontal do Guaíba', tall: true },
  { src: '/images/aerea-torres-orla.jpg', alt: 'Orla de Torres com prédios e o encontro do rio com o mar, vista aérea', location: 'Torres — Orla', tall: false },
]

export function Portfolio() {
  return (
    <section id="portfolio" className="border-y border-border bg-card/40 py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <p className="text-sm font-medium uppercase tracking-widest text-primary">Portfólio</p>
            <h2 className="mt-3 text-balance font-heading text-3xl font-bold tracking-tight sm:text-4xl">
              Trabalhos recentes
            </h2>
          </div>
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
            Uma amostra de captações aéreas em Porto Alegre e Região, em diferentes
            cenários e horários do dia.
          </p>
        </div>

        <div className="mt-12 columns-1 gap-4 sm:columns-2 lg:columns-3">
          {shots.map((shot) => (
            <div
              key={shot.src}
              className="group relative mb-4 break-inside-avoid overflow-hidden rounded-2xl border border-border"
            >
              <img
                src={shot.src || '/placeholder.svg'}
                alt={shot.alt}
                className={`w-full object-cover transition-transform duration-700 group-hover:scale-105 ${
                  shot.tall ? 'aspect-[3/4]' : 'aspect-[4/3]'
                }`}
              />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/90 to-transparent p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                <p className="text-sm font-medium text-foreground">{shot.location}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
