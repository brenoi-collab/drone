import { MessageCircle, MapPin } from 'lucide-react'
import { InstagramIcon } from '@/components/icons'
import { site, whatsappLink } from '@/lib/site'

export function ContactCta() {
  return (
    <section id="contato" className="relative overflow-hidden">
      <img
        src="/images/gallery-3.png"
        alt="Montanhas acima das nuvens ao amanhecer vistas por drone"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-background/85" />

      <div className="relative mx-auto max-w-3xl px-5 py-24 text-center md:py-32">
        <p className="text-sm font-medium uppercase tracking-widest text-primary">Vamos voar juntos</p>
        <h2 className="mt-3 text-balance font-heading text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
          Conte sua ideia e receba um orçamento
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-pretty leading-relaxed text-muted-foreground">
          Me chame no WhatsApp com detalhes do seu projeto — tipo de captação, local e data.
          Respondo rápido com a melhor solução para você.
        </p>

        <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 text-sm font-medium text-primary-foreground transition-transform hover:scale-[1.03]"
          >
            <MessageCircle className="h-5 w-5" />
            Falar no WhatsApp
          </a>
          <a
            href={site.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-border px-8 py-4 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
          >
            <InstagramIcon className="h-5 w-5" />
            Ver no Instagram
          </a>
        </div>

        <p className="mt-8 inline-flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 text-primary" />
          Atendo {site.region}
        </p>
      </div>
    </section>
  )
}
