import { MessageCircle, ArrowDown, MapPin } from 'lucide-react'
import { site, whatsappLink } from '@/lib/site'

export function Hero() {
  return (
    <section id="top" className="relative flex min-h-screen items-center justify-center overflow-hidden">
      <img
        src="/images/aerea-orla-amanhecer.jpg"
        alt="Vista aérea da orla com o sol refletindo no mar ao amanhecer, capturada por drone"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
      <div className="absolute inset-0 bg-gradient-to-r from-background/80 to-transparent" />

      <div className="relative mx-auto w-full max-w-6xl px-5 pt-20">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-medium tracking-wide text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Imagens aéreas profissionais
          </span>

          <h1 className="mt-6 text-balance font-heading text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
            Outro ponto de vista para a sua história.
          </h1>

          <p className="mt-5 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            Filmagem e fotografia com drone que valorizam imóveis, eventos e marcas
            com imagens cinematográficas — do céu até o detalhe que importa.
          </p>

          <p className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-foreground/80">
            <MapPin className="h-4 w-4 text-primary" />
            {site.region}
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-medium text-primary-foreground transition-transform hover:scale-[1.03]"
            >
              <MessageCircle className="h-4 w-4" />
              Pedir orçamento
            </a>
            <a
              href="#portfolio"
              className="inline-flex items-center gap-2 rounded-full border border-border px-7 py-3.5 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
            >
              Ver portfólio
            </a>
          </div>
        </div>
      </div>

      <a
        href="#servicos"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground transition-colors hover:text-foreground"
        aria-label="Ver serviços"
      >
        <ArrowDown className="h-5 w-5 animate-bounce" />
      </a>
    </section>
  )
}
